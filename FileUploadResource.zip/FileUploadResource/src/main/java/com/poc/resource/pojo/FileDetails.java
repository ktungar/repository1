package com.poc.resource.pojo;

import java.util.ArrayList;
import java.util.List;

public class FileDetails {
	private List<String> fileString = new ArrayList<String>();
	private List<String> filesName = new ArrayList<String>();
	private String massage;
	public String getMassage() {
		return massage;
	}
	public void setMassage(String massage) {
		this.massage = massage;
	}
	public List<String> getFileString() {
		return fileString;
	}
	public void setFileString(List<String> fileString) {
		this.fileString = fileString;
	}
	public List<String> getFilesName() {
		return filesName;
	}
	public void setFilesName(List<String> filesName) {
		this.filesName = filesName;
	}

}
