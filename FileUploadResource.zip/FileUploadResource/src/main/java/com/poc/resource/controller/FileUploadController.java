package com.poc.resource.controller;

import java.io.FileNotFoundException;

import javax.annotation.security.RolesAllowed;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import com.poc.resource.pojo.FileDetails;
import com.poc.resource.service.FileUploadResource;

@RestController
@RequestMapping("/secure")

public class FileUploadController {
	@Autowired
	private FileUploadResource uploadResource;
	@PreAuthorize("hasAnyRole('USER')")
	@RequestMapping(value = "/upload", method = RequestMethod.POST)
	public FileDetails uploadFiles(@RequestBody FileDetails fileDetails) throws FileNotFoundException {
		FileDetails details = uploadResource.uploadFilesToLocal(fileDetails.getFileString(),
				fileDetails.getFilesName());

		return details;
	}
}
