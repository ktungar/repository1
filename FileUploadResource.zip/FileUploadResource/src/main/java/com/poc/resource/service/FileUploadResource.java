package com.poc.resource.service;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.util.Base64;
import java.util.List;
import org.springframework.stereotype.Service;

import com.poc.resource.pojo.FileDetails;

@Service
public class FileUploadResource {
	FileDetails details = new FileDetails();

	public FileDetails uploadFilesToLocal(List<String> files, List<String> filesName) throws FileNotFoundException {
		FileOutputStream fout = null;
		try {
			for (int i = 0; i < filesName.size(); i++) {
				fout = new FileOutputStream("C:\\Users\\kunal.tungar\\Desktop\\OneCare Portal\\" + filesName.get(i));
				byte[] bs = Base64.getDecoder().decode(files.get(i));
				fout.write(bs);
			}
			fout.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
		details.setMassage(" File/'s are successfully Uploaded.");
		return details;
	}
}
