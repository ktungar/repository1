package com.poc.resource;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FileUploadResourceApplicationTests {

	@Test
	void contextLoads() {
	}

}
