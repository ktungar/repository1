package com.poc.client.service;

import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Base64;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.client.support.BasicAuthorizationInterceptor;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.multipart.MultipartFile;

import com.poc.client.pojo.FileDetails;

@Service
public class UploadFileService {
	
	final String uri = "http://localhost:8989/secure/upload";
	
	@Value("${ba.username}")
	private String username;
	
	@Value("${ba.password}")
	private String password;

	public ResponseEntity<Object> uploadFile1(List<MultipartFile> file, HttpServletRequest request)
			throws FileNotFoundException {
		List<String> fileString = new ArrayList<String>();
		List<String> filesName = new ArrayList<String>();
		FileDetails fileDetails = new FileDetails();

		try {
			for (int i = 0; i < file.size(); i++) {
				String filesBase64 = Base64.getEncoder().encodeToString(file.get(i).getBytes());
				fileString.add(filesBase64);
				filesName.add(file.get(i).getOriginalFilename());
			}
			fileDetails.setFileString(fileString);
			fileDetails.setFilesName(filesName);

			/*
			 * // create request HttpHeaders headers = new HttpHeaders();
			 * headers.add("Authorization", request.getHeader("Authorization"));
			 * HttpEntity<FileDetails> requestBody = new
			 * HttpEntity<FileDetails>(fileDetails, headers);
			 * 
			 * // consume resource response = new RestTemplate().exchange(uri,
			 * HttpMethod.POST, requestBody, FileDetails.class);
			 */

			System.out.println("username : password   "+ username +" : " +password);
			
			RestTemplate restTemplate = new RestTemplate();
			restTemplate.getInterceptors().add(new BasicAuthorizationInterceptor(username, password));

			fileDetails = restTemplate.postForObject(uri, fileDetails, FileDetails.class);

		} catch (Exception e) {
			e.printStackTrace();
		}
		if (fileDetails.getMassage() != null) {
			return new ResponseEntity<Object>(file.size() + fileDetails.getMassage(), HttpStatus.OK);
		} else {
			return new ResponseEntity<Object>("Access denied : '"+username+"' is Unauthorized", HttpStatus.UNAUTHORIZED);
		}
	}
}
